<?php
/**
 * Plugin Name: RG PS Generator
 * Description: PS1 & PS3 Producer Statement PDF generator for Royal Glass Limited
 * Version:     1.0.0
 * Author:      Royal Glass
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'RGPS_DIR', plugin_dir_path( __FILE__ ) );
define( 'RGPS_URL', plugin_dir_url( __FILE__ ) );

// ── Activation: create table & default options ───────────────────────
register_activation_hook( __FILE__, 'rgps_activate' );
function rgps_activate() {
    global $wpdb;
    $table   = $wpdb->prefix . 'rgps_records';
    $charset = $wpdb->get_charset_collate();
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta( "CREATE TABLE IF NOT EXISTS {$table} (
        id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        created_at      DATETIME DEFAULT CURRENT_TIMESTAMP,
        client_name     VARCHAR(200) NOT NULL,
        address         VARCHAR(300) NOT NULL,
        bc_number       VARCHAR(50),
        lot_description VARCHAR(300),
        system          VARCHAR(50)  NOT NULL,
        substrate       VARCHAR(50)  NOT NULL,
        structure       VARCHAR(100) NOT NULL,
        location        VARCHAR(50)  NOT NULL,
        new_or_existing VARCHAR(20)  NOT NULL,
        ps3_generated   TINYINT(1)   DEFAULT 0,
        filename        VARCHAR(400)
    ) {$charset};" );

    if ( ! get_option( 'rgps_access_password' ) ) {
        add_option( 'rgps_access_password', 'royalglass2025' );
    }
}

// ── Admin settings page ──────────────────────────────────────────────
add_action( 'admin_menu', function () {
    add_options_page( 'RG PS Generator', 'RG PS Generator', 'manage_options', 'rg-ps-generator', 'rgps_settings_page' );
} );

function rgps_settings_page() {
    if ( ! current_user_can( 'manage_options' ) ) return;
    if ( isset( $_POST['rgps_save'] ) ) {
        check_admin_referer( 'rgps_settings' );
        update_option( 'rgps_access_password', sanitize_text_field( $_POST['rgps_access_password'] ) );
        echo '<div class="updated"><p>Saved.</p></div>';
    }
    $pw = esc_attr( get_option( 'rgps_access_password', '' ) );
    echo '<div class="wrap"><h1>RG PS Generator Settings</h1>
    <form method="post">
        ' . wp_nonce_field( 'rgps_settings', '_wpnonce', true, false ) . '
        <table class="form-table">
            <tr><th>Access Password</th>
                <td><input type="text" name="rgps_access_password" value="' . $pw . '" class="regular-text" /></td>
            </tr>
        </table>
        <p><input type="submit" name="rgps_save" class="button-primary" value="Save Changes" /></p>
    </form></div>';
}

// ── Shortcode ────────────────────────────────────────────────────────
add_shortcode( 'rg_ps_generator', 'rgps_shortcode' );
function rgps_shortcode() {
    wp_enqueue_script( 'pdf-lib',   'https://unpkg.com/pdf-lib@1.17.1/dist/pdf-lib.min.js', [], null, true );
    wp_enqueue_script( 'rgps-app',  RGPS_URL . 'assets/app.js', [ 'pdf-lib' ], '1.0.0', true );
    wp_enqueue_style(  'rgps-style', RGPS_URL . 'assets/style.css', [], '1.0.0' );

    wp_localize_script( 'rgps-app', 'RGPSConfig', [
        'ajaxUrl' => admin_url( 'admin-ajax.php' ),
        'nonce'   => wp_create_nonce( 'rgps_nonce' ),
    ] );

    ob_start(); ?>
    <div id="rgps-root">

      <div id="rgps-password-gate">
        <div id="rgps-password-box">
          <h2>Royal Glass — PS1 and PS3 Generator</h2>
          <p>Enter the access password to continue.</p>
          <input type="password" id="rgps-pwd-input" placeholder="Password" />
          <p id="rgps-password-error"></p>
          <button class="rgps-btn rgps-btn-primary" id="rgps-signin-btn">Sign In</button>
        </div>
      </div>

      <div id="rgps-app" style="display:none;">
        <h1>PS1 and PS3 Generator</h1>

        <div class="rgps-card">
          <h2>Project Details</h2>
          <div class="rgps-field">
            <label for="rgps-clientName">Client / Designer Name <span class="rgps-req">*</span></label>
            <input type="text" id="rgps-clientName" placeholder="e.g. Royal Glass" />
          </div>
          <div class="rgps-field">
            <label for="rgps-address">Property Address <span class="rgps-req">*</span></label>
            <input type="text" id="rgps-address" placeholder="e.g. 13E Paul Matthews Rd" />
          </div>
          <div class="rgps-field">
            <label for="rgps-bcNumber">BC Number <span class="rgps-opt">(optional)</span></label>
            <input type="text" id="rgps-bcNumber" placeholder="e.g. BCO12345678" />
          </div>
          <div class="rgps-field">
            <label for="rgps-lotDescription">Lot Description</label>
            <input type="text" id="rgps-lotDescription" />
          </div>
        </div>

        <div class="rgps-card">
          <h2>System &amp; Installation</h2>
          <div class="rgps-field">
            <label for="rgps-system">System</label>
            <select id="rgps-system">
              <option value="mini-post">Mini Post</option>
              <option value="double-disc">Double Disc</option>
              <option value="side-channel">Side Mount Channel</option>
              <option value="top-channel">Top Mount Channel</option>
            </select>
          </div>
          <div class="rgps-field">
            <label for="rgps-substrate">Structure Material</label>
            <select id="rgps-substrate">
              <option value="Timber">Timber</option>
              <option value="Concrete">Concrete</option>
              <option value="Steel">Steel</option>
            </select>
          </div>
          <div class="rgps-field">
            <label for="rgps-structure">Structure Type</label>
            <select id="rgps-structure">
              <option value="Deck">Deck</option>
              <option value="Balcony">Balcony</option>
              <option value="Pool Area">Pool</option>
              <option value="Stair Area">Stair</option>
              <option value="Landing">Landing</option>
              <option value="Stair and Balcony Area">Stair and Balcony</option>
            </select>
          </div>
          <div class="rgps-field">
            <label>Location</label>
            <div class="rgps-radio-group">
              <label><input type="radio" name="rgps-location" value="Internal" /> Internal</label>
              <label><input type="radio" name="rgps-location" value="External" checked /> External</label>
            </div>
          </div>
          <div class="rgps-field">
            <label>Structure Built</label>
            <div class="rgps-radio-group">
              <label><input type="radio" name="rgps-newOrExisting" value="New" checked /> New</label>
              <label><input type="radio" name="rgps-newOrExisting" value="Existing" /> Existing</label>
            </div>
          </div>
          <div class="rgps-field">
            <label for="rgps-thickness">Glass Thickness</label>
            <select id="rgps-thickness">
              <option value="12" selected>12mm</option>
              <option value="15">15mm</option>
            </select>
          </div>
          <div class="rgps-field">
            <label>Gate Required?</label>
            <div class="rgps-radio-group">
              <label><input type="radio" name="rgps-requiresGate" value="Yes" /> Yes</label>
              <label><input type="radio" name="rgps-requiresGate" value="No" checked /> No</label>
            </div>
          </div>
        </div>

        <div class="rgps-btn-row">
          <button class="rgps-btn rgps-btn-primary"   data-mode="ps1">Generate PS1</button>
          <button class="rgps-btn rgps-btn-secondary" data-mode="ps3">Generate PS3</button>
          <button class="rgps-btn rgps-btn-both"      data-mode="both">Generate PS1 and PS3</button>
        </div>
        <div id="rgps-status"></div>

        <div class="rgps-card" style="margin-top:2rem;">
          <h2>Recent Records</h2>
          <table>
            <thead><tr>
              <th>Date</th><th>Client</th><th>Address</th><th>System</th><th>Structure</th><th>PS3</th>
            </tr></thead>
            <tbody id="rgps-records-body">
              <tr><td colspan="6" style="color:#71717a;">Loading…</td></tr>
            </tbody>
          </table>
        </div>
      </div>

    </div>
    <?php
    return ob_get_clean();
}

// ── AJAX: auth ───────────────────────────────────────────────────────
add_action( 'wp_ajax_rgps_auth',        'rgps_handle_auth' );
add_action( 'wp_ajax_nopriv_rgps_auth', 'rgps_handle_auth' );
function rgps_handle_auth() {
    check_ajax_referer( 'rgps_nonce', 'nonce' );

    $ip       = sanitize_text_field( $_SERVER['REMOTE_ADDR'] ?? '' );
    $rateKey  = 'rgps_rate_' . md5( $ip );
    $attempts = (int) get_transient( $rateKey );

    if ( $attempts >= 10 ) {
        wp_send_json( [ 'ok' => false, 'error' => 'Too many attempts. Try again in 15 minutes.' ], 429 );
    }

    $password = sanitize_text_field( $_POST['password'] ?? '' );
    $stored   = get_option( 'rgps_access_password', '' );

    if ( $password !== '' && $password === $stored ) {
        delete_transient( $rateKey );
        $token = bin2hex( random_bytes( 32 ) );
        set_transient( 'rgps_sess_' . $token, 1, 8 * HOUR_IN_SECONDS );
        wp_send_json( [ 'ok' => true, 'token' => $token ] );
    }

    set_transient( $rateKey, $attempts + 1, 15 * MINUTE_IN_SECONDS );
    wp_send_json( [ 'ok' => false, 'error' => 'Wrong password' ], 401 );
}

// ── AJAX: serve template bytes ───────────────────────────────────────
add_action( 'wp_ajax_rgps_template',        'rgps_handle_template' );
add_action( 'wp_ajax_nopriv_rgps_template', 'rgps_handle_template' );
function rgps_handle_template() {
    rgps_verify_token();

    $allowed = [
        'MP_PS1_2026.pdf',
        'MP_GATE_PS1_Template.pdf',
        'DD_PS1_2026.pdf',
        'Side_Channel_PS1_Template.pdf',
        'Top_Channel_PS1_Template.pdf',
        'PS3_Template.pdf',
    ];

    $name = sanitize_file_name( $_GET['name'] ?? '' );
    if ( ! in_array( $name, $allowed, true ) ) {
        wp_send_json( [ 'ok' => false, 'error' => 'Invalid template' ], 400 );
    }

    $path = RGPS_DIR . 'templates/' . $name;
    if ( ! file_exists( $path ) ) {
        wp_send_json( [ 'ok' => false, 'error' => 'Template not found: ' . $name ], 404 );
    }

    wp_send_json( [ 'ok' => true, 'data' => base64_encode( file_get_contents( $path ) ) ] );
}

// ── AJAX: log generation ─────────────────────────────────────────────
add_action( 'wp_ajax_rgps_log',        'rgps_handle_log' );
add_action( 'wp_ajax_nopriv_rgps_log', 'rgps_handle_log' );
function rgps_handle_log() {
    rgps_verify_token();
    global $wpdb;

    $allowed_systems    = [ 'mini-post', 'double-disc', 'side-channel', 'top-channel' ];
    $allowed_substrates = [ 'Timber', 'Concrete', 'Steel' ];
    $allowed_structures = [ 'Deck', 'Balcony', 'Pool Area', 'Pool Fence', 'Stair Area', 'Landing', 'Stair and Balcony Area' ];
    $allowed_locations  = [ 'Internal', 'External' ];
    $allowed_noe        = [ 'New', 'Existing' ];

    $system    = sanitize_text_field( $_POST['system']          ?? '' );
    $substrate = sanitize_text_field( $_POST['substrate']       ?? '' );
    $structure = sanitize_text_field( $_POST['structure']       ?? '' );
    $location  = sanitize_text_field( $_POST['location']        ?? '' );
    $noe       = sanitize_text_field( $_POST['new_or_existing'] ?? '' );

    if ( ! in_array( $system,    $allowed_systems,    true ) ) wp_send_json( [ 'ok' => false ], 400 );
    if ( ! in_array( $substrate, $allowed_substrates, true ) ) wp_send_json( [ 'ok' => false ], 400 );
    if ( ! in_array( $structure, $allowed_structures, true ) ) wp_send_json( [ 'ok' => false ], 400 );
    if ( ! in_array( $location,  $allowed_locations,  true ) ) wp_send_json( [ 'ok' => false ], 400 );
    if ( ! in_array( $noe,       $allowed_noe,        true ) ) wp_send_json( [ 'ok' => false ], 400 );

    $wpdb->insert( $wpdb->prefix . 'rgps_records', [
        'client_name'     => substr( sanitize_text_field( $_POST['client_name']     ?? '' ), 0, 200 ),
        'address'         => substr( sanitize_text_field( $_POST['address']         ?? '' ), 0, 300 ),
        'bc_number'       => substr( sanitize_text_field( $_POST['bc_number']       ?? '' ), 0, 50  ) ?: null,
        'lot_description' => substr( sanitize_text_field( $_POST['lot_description'] ?? '' ), 0, 300 ),
        'system'          => $system,
        'substrate'       => $substrate,
        'structure'       => $structure,
        'location'        => $location,
        'new_or_existing' => $noe,
        'ps3_generated'   => (int) ( $_POST['ps3_generated'] ?? 0 ),
        'filename'        => substr( sanitize_file_name( $_POST['filename'] ?? '' ), 0, 400 ),
    ] );

    wp_send_json( [ 'ok' => true ] );
}

// ── AJAX: recent records ─────────────────────────────────────────────
add_action( 'wp_ajax_rgps_records',        'rgps_handle_records' );
add_action( 'wp_ajax_nopriv_rgps_records', 'rgps_handle_records' );
function rgps_handle_records() {
    rgps_verify_token();
    global $wpdb;
    $rows = $wpdb->get_results(
        "SELECT * FROM {$wpdb->prefix}rgps_records ORDER BY created_at DESC LIMIT 50"
    );
    wp_send_json( [ 'ok' => true, 'rows' => $rows ] );
}

// ── Token verification helper ────────────────────────────────────────
function rgps_verify_token() {
    $token = sanitize_text_field( $_REQUEST['token'] ?? '' );
    if ( ! $token || ! get_transient( 'rgps_sess_' . $token ) ) {
        wp_send_json( [ 'ok' => false, 'error' => 'Unauthorised' ], 401 );
        exit;
    }
}
