(function () {
  'use strict';

  // Injected by wp_localize_script
  const AJAX  = RGPSConfig.ajaxUrl;
  const NONCE = RGPSConfig.nonce;

  // ── System config (mirrors systemConfig.js) ────────────────────────
  const SYSTEMS = {
    'mini-post': {
      displayName:      'Mini Post',
      templateFile:     'MP_PS1_2026.pdf',
      gateTemplateFile: 'MP_GATE_PS1_Template.pdf',
      heights: {
        pool:    { height: '1.26', heightAboveFix: '1.05' },
        default: { height: '1.01', heightAboveFix: '0.85' },
      },
    },
    'double-disc': {
      displayName:  'Double Disc',
      templateFile: 'DD_PS1_2026.pdf',
      heights: {
        pool:    { height: '1.20', heightAboveFix: '1.25' },
        default: { height: '1.00', heightAboveFix: '1.05' },
      },
    },
    'side-channel': {
      displayName:  'Side Mount Channel',
      templateFile: 'Side_Channel_PS1_Template.pdf',
      heights: {
        pool:    { height: '1.2', heightAboveFix: '1.2' },
        default: { height: '1.00', heightAboveFix: '1.00' },
      },
    },
    'top-channel': {
      displayName:  'Top Mount Channel',
      templateFile: 'Top_Channel_PS1_Template.pdf',
      heights: {
        pool:    { height: '1.2', heightAboveFix: '1.2' },
        default: { height: '1.00', heightAboveFix: '1.00' },
      },
    },
  };

  const POOL_STRUCTURES = ['Pool Area', 'Pool Fence'];

  function getSystem(key) {
    const s = SYSTEMS[key];
    if (!s) throw new Error('Unknown system: ' + key);
    return s;
  }

  function getHeights(systemKey, structure) {
    const s      = getSystem(systemKey);
    const bucket = POOL_STRUCTURES.includes(structure) ? 'pool' : 'default';
    return s.heights[bucket];
  }

  function buildDescription(thickness, structure, systemKey) {
    return thickness + 'mm thick Glass Balustrade installation for ' + structure + ' area using ' + getSystem(systemKey).displayName + ' System';
  }

  function buildShortDescription(structure, systemKey) {
    return 'New ' + structure + ' ' + getSystem(systemKey).displayName + ' Glass Balustrade';
  }

  // ── Helpers ────────────────────────────────────────────────────────
  function today() {
    const d  = new Date();
    const dd = String(d.getDate()).padStart(2, '0');
    const mm = String(d.getMonth() + 1).padStart(2, '0');
    return dd + '/' + mm + '/' + d.getFullYear();
  }

  function sanitizeFilename(name) {
    return name.replace(/[/\\?%*:|"<>\r\n\0]/g, '-').replace(/\.\./g, '--').trim();
  }

  function esc(s) {
    return String(s ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  }

  function el(id) { return document.getElementById(id); }

  // ── Session token (localStorage) ──────────────────────────────────
  const TOKEN_KEY = 'rgps_token';
  function getToken()   { return localStorage.getItem(TOKEN_KEY) || ''; }
  function setToken(t)  { localStorage.setItem(TOKEN_KEY, t); }
  function clearToken() { localStorage.removeItem(TOKEN_KEY); }

  // ── AJAX wrapper ───────────────────────────────────────────────────
  async function ajax(action, params = {}, method = 'POST') {
    const fd = new FormData();
    fd.append('action', action);
    fd.append('nonce',  NONCE);
    fd.append('token',  getToken());
    Object.entries(params).forEach(([k, v]) => fd.append(k, v));

    const res = await fetch(AJAX, { method, body: fd });
    return res.json();
  }

  // ── Fetch template bytes from PHP ──────────────────────────────────
  async function fetchTemplate(name) {
    const url = AJAX + '?action=rgps_template&token=' + encodeURIComponent(getToken()) + '&name=' + encodeURIComponent(name);
    const res = await fetch(url);
    const json = await res.json();
    if (!json.ok) throw new Error(json.error || 'Failed to fetch template');
    const binary = atob(json.data);
    const bytes  = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
    return bytes;
  }

  // ── PDF filling (mirrors pdfFiller.js) ────────────────────────────
  async function fillPS1(templateFile, data, heights) {
    const { PDFDocument } = PDFLib;
    const templateBytes   = await fetchTemplate(templateFile);
    const pdf  = await PDFDocument.load(templateBytes);
    const form = pdf.getForm();
    const date = today();

    function setText(name, value) {
      try { form.getTextField(name).setText(value || ''); } catch (_) {}
    }
    function setCheck(name, checked) {
      try { const cb = form.getCheckBox(name); checked ? cb.check() : cb.uncheck(); } catch (_) {}
    }

    setText('Name',            data.clientName);
    setText('Address',         data.address);
    setText('Description',     data.shortDescription);
    setText('Date0',           date);
    setText('Date01',          date);
    setText('Date-4',          date);
    setText('Name-2',          data.clientName);
    setText('Address-2',       data.address);
    setText('Address02',       data.address);
    setText('Address-4',       data.address);
    setText('Thickness',       data.thickness || '12');
    setText('Height',          heights.height);
    setText('HeightAboveFix',  heights.heightAboveFix);

    setCheck('TimberTB',    data.substrate === 'Timber');
    setCheck('ConcreteTB',  data.substrate === 'Concrete');
    setCheck('SteelTB',     data.substrate === 'Steel');
    setCheck('InternalTB',  data.location === 'Internal');
    setCheck('ExternalTB',  data.location === 'External');
    setCheck('NewTB',       data.newOrExisting === 'New');
    setCheck('ExistingTB',  data.newOrExisting === 'Existing');
    setCheck('ToughenedTB', true);
    setCheck('Direct',      true);
    setCheck('Cont',        false);

    form.flatten();
    return pdf.save();
  }

  async function fillPS3(data) {
    const { PDFDocument } = PDFLib;
    const templateBytes   = await fetchTemplate('PS3_Template.pdf');
    const pdf  = await PDFDocument.load(templateBytes);
    const form = pdf.getForm();

    function setText(name, value) {
      try { form.getTextField(name).setText(value || ''); } catch (_) {}
    }
    function setCheck(name, checked) {
      try { const cb = form.getCheckBox(name); checked ? cb.check() : cb.uncheck(); } catch (_) {}
    }

    setText('BC',           data.bcNumber || '');
    setText('Address02',    data.address);
    setText('Description3', data.structure);
    setText('Description2', data.longDescription);
    setText('Date03',       today());
    setText('Legal',        data.lotDescription || '');

    setCheck('B1TB',    true);
    setCheck('B2TB',    false);
    setCheck('F4TB',    true);
    setCheck('GlassTB', true);
    setCheck('PS1TB',   true);

    form.flatten();
    return pdf.save();
  }

  // ── Trigger browser download ───────────────────────────────────────
  function triggerDownload(bytes, filename) {
    const blob = new Blob([bytes], { type: 'application/pdf' });
    const url  = URL.createObjectURL(blob);
    const a    = document.createElement('a');
    a.href     = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(url), 2000);
  }

  // ── Read form values ───────────────────────────────────────────────
  function formData() {
    return {
      clientName:     el('rgps-clientName').value.trim(),
      address:        el('rgps-address').value.trim(),
      bcNumber:       el('rgps-bcNumber').value.trim(),
      lotDescription: el('rgps-lotDescription').value.trim(),
      thickness:      el('rgps-thickness').value,
      system:         el('rgps-system').value,
      substrate:      el('rgps-substrate').value,
      structure:      el('rgps-structure').value,
      location:       document.querySelector('input[name="rgps-location"]:checked').value,
      newOrExisting:  document.querySelector('input[name="rgps-newOrExisting"]:checked').value,
      requiresGate:   document.querySelector('input[name="rgps-requiresGate"]:checked').value === 'Yes',
    };
  }

  // ── Generate ───────────────────────────────────────────────────────
  async function generate(mode) {
    const status = el('rgps-status');
    const fd     = formData();

    if (!fd.clientName) {
      status.className = 'rgps-status-error';
      status.textContent = 'Client / Designer Name is required.';
      el('rgps-clientName').focus();
      return;
    }
    if (!fd.address) {
      status.className = 'rgps-status-error';
      status.textContent = 'Property Address is required.';
      el('rgps-address').focus();
      return;
    }

    const btns = document.querySelectorAll('#rgps-app .rgps-btn');
    btns.forEach(b => b.disabled = true);
    status.className   = '';
    status.textContent = 'Generating…';

    try {
      const sys     = getSystem(fd.system);
      const heights = getHeights(fd.system, fd.structure);
      const data    = {
        ...fd,
        longDescription:  buildDescription(fd.thickness, fd.structure, fd.system),
        shortDescription: buildShortDescription(fd.structure, fd.system),
      };

      if (mode === 'ps3') {
        const bytes    = await fillPS3(data);
        const filename = sanitizeFilename(fd.address + ' - PS3.pdf');
        triggerDownload(bytes, filename);
        await ajax('rgps_log', { ...fd, ps3_generated: 1, filename, new_or_existing: fd.newOrExisting });

      } else if (mode === 'ps1') {
        const templateFile = fd.system === 'mini-post' && fd.requiresGate
          ? sys.gateTemplateFile
          : sys.templateFile;
        const bytes    = await fillPS1(templateFile, data, heights);
        const filename = sanitizeFilename(fd.address + ' - PS1.pdf');
        triggerDownload(bytes, filename);
        await ajax('rgps_log', { ...fd, ps3_generated: 0, filename, new_or_existing: fd.newOrExisting });

      } else {
        // both
        const templateFile = fd.system === 'mini-post' && fd.requiresGate
          ? sys.gateTemplateFile
          : sys.templateFile;
        const [ps3Bytes, ps1Bytes] = await Promise.all([
          fillPS3(data),
          fillPS1(templateFile, data, heights),
        ]);
        const ps3File = sanitizeFilename(fd.address + ' - PS3.pdf');
        const ps1File = sanitizeFilename(fd.address + ' - PS1.pdf');
        triggerDownload(ps3Bytes, ps3File);
        triggerDownload(ps1Bytes, ps1File);
        await ajax('rgps_log', { ...fd, ps3_generated: 1, filename: ps1File, new_or_existing: fd.newOrExisting });
      }

      status.className   = 'rgps-status-ok';
      status.textContent = mode === 'both' ? '2 PDFs downloaded.' : 'PDF downloaded.';
      loadRecords();

    } catch (err) {
      status.className   = 'rgps-status-error';
      status.textContent = err.message || 'An error occurred.';
    } finally {
      btns.forEach(b => b.disabled = false);
    }
  }

  // ── Records table ──────────────────────────────────────────────────
  async function loadRecords() {
    const tbody = el('rgps-records-body');
    try {
      const json = await ajax('rgps_records');
      if (!json.ok || !json.rows.length) {
        tbody.innerHTML = '<tr><td colspan="6" style="color:#71717a;">No records yet.</td></tr>';
        return;
      }
      tbody.innerHTML = json.rows.slice(0, 20).map(r => {
        const date = new Date(r.created_at).toLocaleDateString('en-NZ', { day: '2-digit', month: 'short', year: 'numeric' });
        const ps3  = r.ps3_generated
          ? '<span class="rgps-tag rgps-tag-yes">Yes</span>'
          : '<span class="rgps-tag rgps-tag-no">No</span>';
        return '<tr><td>' + date + '</td><td>' + esc(r.client_name) + '</td><td>' + esc(r.address) + '</td><td>' + esc(r.system) + '</td><td>' + esc(r.structure) + '</td><td>' + ps3 + '</td></tr>';
      }).join('');
    } catch {
      tbody.innerHTML = '<tr><td colspan="6" style="color:#dc2626;">Could not load records.</td></tr>';
    }
  }

  // ── Auth ───────────────────────────────────────────────────────────
  async function submitPassword() {
    const errEl = el('rgps-password-error');
    errEl.textContent  = '';
    errEl.style.display = 'none';
    try {
      const pwd = el('rgps-pwd-input').value;
      const fd  = new FormData();
      fd.append('action',   'rgps_auth');
      fd.append('nonce',    NONCE);
      fd.append('password', pwd);
      const res  = await fetch(AJAX, { method: 'POST', body: fd });
      const json = await res.json();
      if (json.ok) {
        setToken(json.token);
        showApp();
      } else {
        errEl.textContent   = json.error || 'Incorrect password.';
        errEl.style.display = 'block';
      }
    } catch {
      errEl.textContent   = 'Could not reach the server.';
      errEl.style.display = 'block';
    }
  }

  function showApp() {
    el('rgps-password-gate').style.display = 'none';
    el('rgps-app').style.display = 'block';
    loadRecords();
  }

  // ── Boot ───────────────────────────────────────────────────────────
  document.addEventListener('DOMContentLoaded', function () {
    // Check existing session
    if (getToken()) {
      ajax('rgps_records').then(json => {
        if (json.ok) showApp();
        else clearToken();
      }).catch(() => {});
    }

    // Sign in button
    el('rgps-signin-btn').addEventListener('click', submitPassword);
    el('rgps-pwd-input').addEventListener('keydown', e => { if (e.key === 'Enter') submitPassword(); });

    // Generate buttons
    document.querySelectorAll('#rgps-app .rgps-btn[data-mode]').forEach(btn => {
      btn.addEventListener('click', () => generate(btn.dataset.mode));
    });
  });

})();
